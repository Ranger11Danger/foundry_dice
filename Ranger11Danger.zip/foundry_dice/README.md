# foundry_dice

Custom YEET/FUCK text replacing the 1 and 20 on the d20. Available in black and red text.